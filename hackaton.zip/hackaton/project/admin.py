from django.contrib import admin

from .models import Project, Job

# Register your models here.

admin.site.register(Project)
admin.site.register(Job)
